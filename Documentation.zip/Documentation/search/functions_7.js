var searchData=
[
  ['image',['Image',['../classImage.html#ac24a534d873715234e0f056a98872691',1,'Image::Image(unsigned w, unsigned h, unsigned d)'],['../classImage.html#a0a156f67cc7c0cb76ead922351de48f9',1,'Image::Image(const char *fname)']]],
  ['init_5fgl_5fwindow',['init_gl_window',['../EyeGame_8cpp.html#a5fd5da323be71ae7b0e03ee058f47181',1,'EyeGame.cpp']]],
  ['inmat',['inMat',['../helpers_8cpp.html#adf7b3ef194d11d62c2ba4e2ad062e008',1,'inMat(cv::Point p, int rows, int cols):&#160;helpers.cpp'],['../helpers_8h.html#adf7b3ef194d11d62c2ba4e2ad062e008',1,'inMat(cv::Point p, int rows, int cols):&#160;helpers.cpp']]]
];
