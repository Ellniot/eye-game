var searchData=
[
  ['pixel',['pixel',['../structpixel.html',1,'']]]
];
