var searchData=
[
  ['radius',['radius',['../classCircle.html#a897ad7e556f1e90142093c69079d8b05',1,'Circle::radius()'],['../EyeGame_8cpp.html#a918185208e6ca9759d6696b3449f680e',1,'RADIUS():&#160;EyeGame.cpp']]],
  ['rectinimage',['rectInImage',['../helpers_8cpp.html#ae628fcc78026e5434e47d1d452cfde14',1,'rectInImage(cv::Rect rect, cv::Mat image):&#160;helpers.cpp'],['../helpers_8h.html#ae628fcc78026e5434e47d1d452cfde14',1,'rectInImage(cv::Rect rect, cv::Mat image):&#160;helpers.cpp']]],
  ['red',['red',['../structpixel.html#a82f62245d4b2c3d8c4b9e7f4a62dc7cc',1,'pixel']]],
  ['releasecornerkernels',['releaseCornerKernels',['../findEyeCorner_8cpp.html#aef09cfa8095b51ec840b3cf0b31b47e7',1,'releaseCornerKernels():&#160;findEyeCorner.cpp'],['../findEyeCorner_8h.html#aef09cfa8095b51ec840b3cf0b31b47e7',1,'releaseCornerKernels():&#160;findEyeCorner.cpp']]],
  ['rightcornerkernel',['rightCornerKernel',['../findEyeCorner_8cpp.html#aa51ab237846498f3c500159ee9d3648a',1,'findEyeCorner.cpp']]],
  ['rng',['rng',['../EyeInterface_8cpp.html#abaa8fac8afd813eea8814d3e6448caa6',1,'EyeInterface.cpp']]],
  ['rotatept',['rotatePt',['../Texture_8cpp.html#a66a66bb56ac5f9b52bb98a5d5e4c0a69',1,'Texture.cpp']]]
];
