var searchData=
[
  ['radius',['radius',['../classCircle.html#a897ad7e556f1e90142093c69079d8b05',1,'Circle::radius()'],['../EyeGame_8cpp.html#a918185208e6ca9759d6696b3449f680e',1,'RADIUS():&#160;EyeGame.cpp']]],
  ['red',['red',['../structpixel.html#a82f62245d4b2c3d8c4b9e7f4a62dc7cc',1,'pixel']]],
  ['rightcornerkernel',['rightCornerKernel',['../findEyeCorner_8cpp.html#aa51ab237846498f3c500159ee9d3648a',1,'findEyeCorner.cpp']]]
];
