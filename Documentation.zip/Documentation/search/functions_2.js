var searchData=
[
  ['circle',['Circle',['../classCircle.html#ad1ecfcfc7bf34529c6a6d6c448bf70fe',1,'Circle::Circle()'],['../classCircle.html#ada80134a5649c242d177f3485246268d',1,'Circle::Circle(int xcoord, int ycoord, int r)'],['../classCircle.html#ad1ecfcfc7bf34529c6a6d6c448bf70fe',1,'Circle::Circle()'],['../classCircle.html#ada80134a5649c242d177f3485246268d',1,'Circle::Circle(int xcoord, int ycoord, int r)']]],
  ['collidewithwalllevel1',['collideWithWallLevel1',['../EyeGame_8cpp.html#aa43265a47ca1b5e653ac0d03baa1fa92',1,'EyeGame.cpp']]],
  ['collidewithwalllevel2',['collideWithWallLevel2',['../EyeGame_8cpp.html#a78ecd26e56b2fc60780a4a9624d39946',1,'EyeGame.cpp']]],
  ['collidewithwalllevel3',['collideWithWallLevel3',['../EyeGame_8cpp.html#a46ebd9c496b20c3529f8dd4b5ec03dfd',1,'EyeGame.cpp']]],
  ['computedynamicthreshold',['computeDynamicThreshold',['../helpers_8cpp.html#a3afd8f7e6419b538bc8ce45a43973f7f',1,'computeDynamicThreshold(const cv::Mat &amp;mat, double stdDevFactor):&#160;helpers.cpp'],['../helpers_8h.html#a3afd8f7e6419b538bc8ce45a43973f7f',1,'computeDynamicThreshold(const cv::Mat &amp;mat, double stdDevFactor):&#160;helpers.cpp']]],
  ['computematxgradient',['computeMatXGradient',['../findEyeCenter_8cpp.html#adb92707ed8ea87e51e4848d2a01fe308',1,'findEyeCenter.cpp']]],
  ['createaboutgamewindow',['createAboutGameWindow',['../EyeGame_8cpp.html#a0c5c9b23befeba090730aae944cf29b5',1,'EyeGame.cpp']]],
  ['createaftermazewindow',['createAfterMazeWindow',['../EyeGame_8cpp.html#a58271744db60e2dfbfa81c403d30287d',1,'EyeGame.cpp']]],
  ['createballgamewindow',['createBallGameWindow',['../EyeGame_8cpp.html#addfe08c4b5a45a0e0e067984494c7b62',1,'EyeGame.cpp']]],
  ['createcornerkernels',['createCornerKernels',['../findEyeCorner_8cpp.html#a84634614ae551d429df5454f9d0f1965',1,'createCornerKernels():&#160;findEyeCorner.cpp'],['../findEyeCorner_8h.html#a84634614ae551d429df5454f9d0f1965',1,'createCornerKernels():&#160;findEyeCorner.cpp']]],
  ['createmazegamelevel1window',['createMazeGameLevel1Window',['../EyeGame_8cpp.html#a371dc01bea9710fafd9f1ed8d5b139d2',1,'EyeGame.cpp']]],
  ['createmazegamelevel2window',['createMazeGameLevel2Window',['../EyeGame_8cpp.html#a8f5ef00233d6102fb082195e62815cc9',1,'EyeGame.cpp']]],
  ['createmazegamelevel3window',['createMazeGameLevel3Window',['../EyeGame_8cpp.html#a0f61a50b77c9a846e0b159a6b8fbf45b',1,'EyeGame.cpp']]],
  ['createnewwindow',['createNewWindow',['../EyeGame_8cpp.html#a316966f9c7fdbd1fd1ad881035337cd2',1,'EyeGame.cpp']]],
  ['createplaygroundwindow',['createPlaygroundWindow',['../EyeGame_8cpp.html#a7a27d088110912bc68b7db4056e64549',1,'EyeGame.cpp']]],
  ['createstartwindow',['createStartWindow',['../EyeGame_8cpp.html#a3b9dde9df49e38e2ce46bc92303034c6',1,'EyeGame.cpp']]]
];
