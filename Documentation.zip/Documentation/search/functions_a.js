var searchData=
[
  ['main',['main',['../EyeGame_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'EyeGame.cpp']]],
  ['matrixmagnitude',['matrixMagnitude',['../helpers_8cpp.html#a285c8d8bbf5c948ae332c5541460640f',1,'matrixMagnitude(const cv::Mat &amp;matX, const cv::Mat &amp;matY):&#160;helpers.cpp'],['../helpers_8h.html#a285c8d8bbf5c948ae332c5541460640f',1,'matrixMagnitude(const cv::Mat &amp;matX, const cv::Mat &amp;matY):&#160;helpers.cpp']]],
  ['mouse',['mouse',['../EyeGame_8cpp.html#a37ef1d79f944d5ebf3363950ce440ffb',1,'EyeGame.cpp']]],
  ['mouse2',['mouse2',['../EyeGame_8cpp.html#a020850081e5c27cefb78c69b5cc800c0',1,'EyeGame.cpp']]],
  ['mouse_5fmotion',['mouse_motion',['../EyeGame_8cpp.html#a106e8d758fbc6e0a545e16812024189d',1,'EyeGame.cpp']]],
  ['moveimgdatatographicscard',['moveImgDataToGraphicsCard',['../structTexture.html#acfe6ccc292d2bbcd70bf991de0bae79d',1,'Texture']]]
];
