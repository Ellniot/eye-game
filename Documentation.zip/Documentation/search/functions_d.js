var searchData=
[
  ['rectinimage',['rectInImage',['../helpers_8cpp.html#ae628fcc78026e5434e47d1d452cfde14',1,'rectInImage(cv::Rect rect, cv::Mat image):&#160;helpers.cpp'],['../helpers_8h.html#ae628fcc78026e5434e47d1d452cfde14',1,'rectInImage(cv::Rect rect, cv::Mat image):&#160;helpers.cpp']]],
  ['releasecornerkernels',['releaseCornerKernels',['../findEyeCorner_8cpp.html#aef09cfa8095b51ec840b3cf0b31b47e7',1,'releaseCornerKernels():&#160;findEyeCorner.cpp'],['../findEyeCorner_8h.html#aef09cfa8095b51ec840b3cf0b31b47e7',1,'releaseCornerKernels():&#160;findEyeCorner.cpp']]],
  ['rng',['rng',['../EyeInterface_8cpp.html#abaa8fac8afd813eea8814d3e6448caa6',1,'EyeInterface.cpp']]],
  ['rotatept',['rotatePt',['../Texture_8cpp.html#a66a66bb56ac5f9b52bb98a5d5e4c0a69',1,'Texture.cpp']]]
];
