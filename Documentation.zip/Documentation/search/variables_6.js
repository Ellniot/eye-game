var searchData=
[
  ['gaze_5fx',['gaze_x',['../EyeInterface_8cpp.html#af78c581e864ed8dac2fa0cfeaff7ff9c',1,'EyeInterface.cpp']]],
  ['gaze_5fy',['gaze_y',['../EyeInterface_8cpp.html#a8e7ce748a31ba81ab71467e56f85c38e',1,'EyeInterface.cpp']]],
  ['globaltexture',['globalTexture',['../Texture_8cpp.html#af3e418dbb70ee4b2a4e39529847359a5',1,'Texture.cpp']]],
  ['green',['green',['../structpixel.html#a6b8a3934ed6b94ccdbaef2306b495091',1,'pixel']]]
];
